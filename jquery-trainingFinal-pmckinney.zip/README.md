jquery-training
===============

JQuery final training assignment.
